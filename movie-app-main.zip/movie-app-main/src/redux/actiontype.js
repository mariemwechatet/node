export const ADD_MOVIE = 'ADD_MOVIE'
export const DELETE_MOVIE='DELETE_MOVIE'
export const EDIT_MOVIE ='EDIT_MOVIE'
export const FILTER_MOVIE='FILTER_MOVIE'