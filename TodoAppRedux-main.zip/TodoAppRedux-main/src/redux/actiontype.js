export const ADD_TASK = 'ADD_TASK'
export const DELETE_TASK='DELETE_TASK'
export const UPDATE_ITEM='UPDATE_ITEM'
export const EDIT_TASK='EDIT_TASK'
export const FILTER_TASK='FILTER_TASK'



